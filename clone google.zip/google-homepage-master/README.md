# Google Homepage Clone
## *By Stephanie Gurung*

A clone of the Google Homepage: My first repo for the Odin Project.
Project instructions: http://www.theodinproject.com/web-development-101/html-css?ref=lc-pb

## Technologies Used

* HTML<br>
* CSS<br>

Installation
------------
Clone Github Repository:
```
$ git clone https://github.com/stephr3/google-homepage.git
```
Open index.html file in your browser of choice.

License
-------
_This software is licensed under the MIT license._<br>
Copyright (c) 2014 *Stephanie Gurung*
